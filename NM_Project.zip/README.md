# Root Finding Algorithms Visualizer

A fully interactive visualizer for numerical root-finding methods built with React + Vite.

## Algorithms Included

| Algorithm | Convergence | Needs |
|---|---|---|
| Bisection | Linear | f(a) and f(b) opposite signs |
| Newton-Raphson | Quadratic (fastest) | f'(x) computable, one guess |
| Secant | Superlinear | Two initial guesses |
| Regula Falsi | Superlinear | f(a) and f(b) opposite signs |

## Setup & Run

### Prerequisites
- Node.js v18+ installed (https://nodejs.org)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open in browser
# → http://localhost:5173
```

### Build for production

```bash
npm run build
npm run preview
```

## How to Use

1. **Enter a function** in the f(x) field — use math syntax like `x^3 - x - 2`, `cos(x) - x`, `e^x - 3`
2. **Choose an algorithm** from the left panel
3. **Set parameters** (interval [a,b] or initial guesses x₀, x₁)
4. Click **Step →** to go one iteration at a time, or **▶ Run Auto** to animate
5. Watch the graph update live showing the current estimate, interval, and tangent lines
6. View iteration details in the table or error convergence chart at the bottom
7. Export results as CSV using the Export button

## Supported Function Syntax

Uses mathjs — you can write:

- `x^3 - x - 2`
- `cos(x) - x`
- `sqrt(x) - 2`
- `e^x - 3` or `exp(x) - 3`
- `log(x) - 1` (natural log)
- `x * sin(x) - 1`
- `x^2 - 4`

## Project Structure

```
src/
├── algorithms/
│   ├── index.js          # exports all algorithms + presets
│   ├── bisection.js
│   ├── newton.js
│   ├── secant.js
│   └── regulaFalsi.js
├── components/
│   ├── FunctionPlot.jsx  # canvas-based graph
│   ├── ErrorChart.jsx    # recharts error convergence
│   ├── IterationTable.jsx
│   └── AlgoInfo.jsx
├── hooks/
│   └── useRootFinder.js  # all state logic
├── App.jsx
├── App.css
├── index.css
└── main.jsx
```

## Adding New Algorithms

1. Create `src/algorithms/myMethod.js` with a `myMethodStep(f, ...)` function
2. Add its info object and export
3. Import it in `src/algorithms/index.js` and add to the `ALGORITHMS` object
4. Handle the new `algKey` case in `useRootFinder.js` inside `doStep()`

## Tech Stack

- React 18 + Vite 5
- mathjs (function parsing + symbolic differentiation)
- recharts (error convergence chart)
- HTML5 Canvas (function plot)
